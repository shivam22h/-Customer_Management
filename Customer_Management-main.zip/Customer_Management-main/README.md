# Customer Management
- A project made in ASP.NET framework
- A login page that logs user in based on the connected sql server database
- Authorises admin login serperately from normal users
- Uses HTML, CSS, JS, C#, SQL
- svg: https://github.com/FortAwesome/Font-Awesome/blob/6.x/svgs/solid/lines-leaning.svg
